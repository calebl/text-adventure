# Live validation of fix/npc-arrival-turn-integrity-20260908 (83f56d8)

Everything below was driven against the **real running app** — `bin/dev` (Puma + a
Solid Queue worker) on port **3142** (never 3000), against this worktree's own
isolated development SQLite databases, played through a headless Chromium at
`http://127.0.0.1:3142` by typing in the play box and clicking the battle panel.
The captain's dev database and port 3000 were not touched.

## No paid model calls

The intent forbids further spend, so the app was pointed at a **local fake
provider** instead of openrouter.ai:

* `harness/fake_provider.rb` — a deterministic OpenAI-compatible server on
  `127.0.0.1:18434`. Schema'd calls are answered by synthesizing a value for
  every property the app's own `json_schema` declares; `POST /admin/control`
  chooses an enum member (including one that is **not** offered), truncates a
  field at its declared cap, delays a reply, or returns 503/401. Streaming
  narrator calls get SSE chunks. Every request is logged with the exact prompt.
* `harness/fake_provider_boot.rb` — loaded via `RUBYOPT`, it overrides
  `RubyLLM::Providers::OpenRouter#api_base` only. **Nothing in the worktree was
  modified** (`git status` is clean).
* `OPENROUTER_API_KEY=fake-local-key`. `harness/calls.jsonl` and
  `provider-call-index.txt` are the complete list of model calls the app made:
  all of them local, all free.

Reproduce:

```bash
FAKE_PORT=18434 FAKE_CALL_LOG=$PWD/calls.jsonl ruby harness/fake_provider.rb &
PORT=3142 TA_DEBUG_VIEW=0 \
  RUBYOPT="-r$PWD/harness/fake_provider_boot.rb" \
  FAKE_PROVIDER_BASE=http://127.0.0.1:18434 OPENROUTER_API_KEY=fake-local-key bin/dev
```

`TA_DEBUG_VIEW=0` turns the debug panel off, so the screenshots are the surface
an ordinary player sees.

## Screenshots

| File | What it shows |
| --- | --- |
| `01-npc-gives-key.png` | Maren's turn after she chose `give:10` from the closed set |
| `02-npc-ceasefire-ends-fight.png` | her `ceasefire` choice ends the fight in the page's own words |
| `03-npc-follows-into-courtyard.png` | after `follow`, she is in the room the player walked into |
| `04-malformed-dialogue-no-effect.png` | dialogue malformed on every attempt: the app's failure notice, no effect applied |
| `05-toll-notice-visible-in-log.png` | the engine's crossing-cost notice under arrival prose that never mentions the injury |
| `06-queued-line-acknowledged.png` | `> /go The Causeway Court` echoed while an earlier turn is still running |
| `07-renderer-outage-factual-arrival.png` | renderer unavailable: the crossing still stands, described from the records |
| `08-generation-resumed-arrival.png` | the room whose interrupted generation resumed without a second paid call |
| `09-no-narrator-completed-turn.png` | no `OPENROUTER_API_KEY`: turn finishes on engine prose, notice names both ways out |
| `10-no-narrator-unfinished-turn.png` | an unslashed line with no classifier: the "did not finish" copy, form returned |

## Other evidence

* `persisted-state.txt` — every NPC decision with the engine's receipt
  (`applied` / `rejected` / `none`), the item that moved, the ceasefire and
  follow rows, the toll rows, the submission table, and the Vestry Hulk's
  cleared checkpoint.
* `arrival-context-delivered.txt` — the arrival prompt the app actually sent for
  the tolled crossing: live cast, the player's wounds, what is lying there, what
  is carried, and the exact crossing outcome.
* `provider-call-index.txt` / `harness/calls.jsonl` — the call ledger. The
  resume case is visible in it: one `Location__DetailSchema` answer, then only
  `Location__ExitsSchema` on re-entry.
* `harness/server.log`, `harness/server-nokey.log` — the app's own output for
  the two runs (with and without a configured model).
