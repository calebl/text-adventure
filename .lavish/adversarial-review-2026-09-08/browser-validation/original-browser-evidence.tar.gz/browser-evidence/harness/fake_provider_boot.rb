# Loaded via RUBYOPT so the running Rails app's OpenRouter provider talks to a
# local fake provider instead of openrouter.ai. Nothing in the worktree is
# modified: this file lives in the run's evidence directory and only overrides
# RubyLLM::Providers::OpenRouter#api_base.
module FakeProviderBase
  def self.install!
    return if @installed
    return unless defined?(::RubyLLM::Providers::OpenRouter)

    ::RubyLLM::Providers::OpenRouter.class_eval do
      def api_base
        ENV.fetch("FAKE_PROVIDER_BASE")
      end
    end
    @installed = true
    warn "[fake-provider] openrouter api_base -> #{ENV['FAKE_PROVIDER_BASE']}"
  end
end

module Kernel
  alias_method :fake_provider_untouched_require, :require

  def require(name)
    result = fake_provider_untouched_require(name)
    FakeProviderBase.install! if name.to_s.include?("ruby_llm")
    result
  end
  private :require
end
