#!/usr/bin/env bash
H="$(cd "$(dirname "$0")" && pwd)"
cd "$H"
FAKE_PORT=18434 FAKE_CALL_LOG="$H/calls.jsonl" exec ruby fake_provider.rb
