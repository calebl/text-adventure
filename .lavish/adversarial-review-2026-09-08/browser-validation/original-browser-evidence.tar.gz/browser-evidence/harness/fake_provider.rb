#!/usr/bin/env ruby
# A local, free, deterministic OpenAI-compatible provider for driving the real
# text-adventure app in a browser with no paid model calls.
#
#   GET  /health            -> ok
#   POST /admin/control     -> set the next replies (JSON body, see CONTROL)
#   GET  /admin/calls       -> every request the app has made, as JSON
#   POST /chat/completions  -> the provider endpoint RubyLLM calls
#
# Schema'd calls are answered by synthesizing a value for every property the
# app's own json_schema declares, so any schema in the app is answerable.
# Control overrides let a test pick an enum member (including one that is NOT
# offered), truncate a field at its cap, or make the provider unavailable.
require "socket"
require "json"

PORT = Integer(ENV.fetch("FAKE_PORT", "18434"))
CALL_LOG = ENV.fetch("FAKE_CALL_LOG")

MUTEX = Mutex.new
STATE = {
  control: { "interaction" => {}, "narrator" => {}, "once" => [] },
  calls: []
}

PEOPLE = {
  "fullname" => "Halber Coyne",
  "nickname" => "Halber",
  "appearance" => "A wiry man in a tarred coat, stooped under the canted deckhead.",
  "personality" => "Wary of strangers and quietly helpful once you have said your business.",
  "backstory" => "Halber Coyne keeps the court's papers dry in the hulk and knows which of them matter.",
  "likes" => "dry paper, a fair copy",
  "dislikes" => "damp, hurry",
  "fears" => "losing a docket",
  "race" => "Shorefolk",
  "name" => "salvage ledger",
  "inscription" => "MARIANNE DOWE -- salvage account, unsigned.",
  "summary" => "The moment the world already recorded."
}

PROSE = {
  "pre_thought" => "She weighs what Cal has just said against the morning's misunderstanding.",
  "pre_feeling" => "wary, curious",
  "action" => "\"Then we settle it plainly,\" Maren says, shifting her staff to her off hand.",
  "post_feeling" => "steadier, resolved",
  "post_thought" => "She decides the gate matters less than the man in front of it.",
  "inner_resolution" => "She will keep whatever bargain she makes at this gate."
}

NARRATION = "Maren lets the staff rest against the gatepost and looks at you levelly, and the courtyard " \
            "noise behind her seems to drop away while she makes up her mind."

def now = Time.now.to_i

def log_call(entry)
  MUTEX.synchronize do
    STATE[:calls] << entry
    File.open(CALL_LOG, "a") { |file| file.puts(entry.to_json) }
  end
end

def control_for(kind)
  MUTEX.synchronize do
    once = STATE[:control]["once"] || []
    index = once.index { |item| item["match"] == kind }
    return once.delete_at(index) if index

    (STATE[:control][kind] || {}).dup
  end
end

def synth(schema, control)
  properties = schema["properties"] || {}
  properties.each_with_object({}) do |(name, spec), out|
    out[name] = value_for(name, spec, control)
  end
end

def value_for(name, spec, control)
  fields = control["fields"] || {}
  return fields[name] if fields.key?(name)

  if spec["enum"]
    wanted = control["enum"] && control["enum"][name]
    if wanted.is_a?(Hash)
      chosen = spec["enum"].find { |member| member.start_with?(wanted["starts_with"].to_s) }
      return chosen || wanted["fallback"] || "none"
    end
    return wanted if wanted
    return "none" if spec["enum"].include?("none")

    return spec["enum"].first
  end

  case spec["type"]
  when "string"
    string_for(name, spec, control)
  when "integer" then Integer(spec["minimum"] || 1)
  when "number" then 1
  when "boolean" then true
  when "array" then [ value_for(name, spec["items"] || { "type" => "string" }, control) ]
  when "object" then synth(spec, control)
  when "null" then nil
  else
    string_for(name, spec, control)
  end
end

def string_for(name, spec, control)
  cap = spec["maxLength"]
  if control["truncate"] == name && cap
    # Exactly the cap the schema asked the field to stay under: what the app
    # treats as a field cut off mid-word.
    return ("word " * cap)[0, cap]
  end
  return PROSE[name] if PROSE.key?(name)
  return PEOPLE[name] if PEOPLE.key?(name)

  text = "The #{name.to_s.tr('_', ' ')} the world already recorded."
  cap ? text[0, cap] : text
end

def json_body(content, model)
  {
    id: "fake-#{now}", object: "chat.completion", created: now, model: model,
    choices: [ { index: 0, message: { role: "assistant", content: content }, finish_reason: "stop" } ],
    usage: { prompt_tokens: 100, completion_tokens: 50, total_tokens: 150 }
  }.to_json
end

def write_json(socket, body, status: "200 OK")
  socket.write("HTTP/1.1 #{status}\r\nContent-Type: application/json\r\nContent-Length: #{body.bytesize}\r\n" \
               "Connection: close\r\n\r\n#{body}")
end

def write_stream(socket, text, model)
  socket.write("HTTP/1.1 200 OK\r\nContent-Type: text/event-stream\r\nCache-Control: no-cache\r\n" \
               "Transfer-Encoding: chunked\r\nConnection: close\r\n\r\n")
  send_chunk = lambda do |payload|
    line = "data: #{payload}\n\n"
    socket.write("#{line.bytesize.to_s(16)}\r\n#{line}\r\n")
  end
  text.scan(/.{1,60}/m).each do |part|
    send_chunk.call({ id: "fake-#{now}", object: "chat.completion.chunk", created: now, model: model,
                      choices: [ { index: 0, delta: { content: part }, finish_reason: nil } ] }.to_json)
    sleep 0.05
  end
  send_chunk.call({ id: "fake-#{now}", object: "chat.completion.chunk", created: now, model: model,
                    choices: [ { index: 0, delta: {}, finish_reason: "stop" } ],
                    usage: { prompt_tokens: 100, completion_tokens: 50, total_tokens: 150 } }.to_json)
  send_chunk.call("[DONE]")
  socket.write("0\r\n\r\n")
end

def handle_completion(socket, request)
  body = JSON.parse(request[:body])
  schema = body.dig("response_format", "json_schema")
  kind = if schema
    schema["name"].to_s.include?("interaction") ? "interaction" : "schema:#{schema['name']}"
  else
    "narrator"
  end
  control = control_for(kind)
  control = control_for("schema") if control.empty? && kind.start_with?("schema:")
  log_call(time: Time.now.iso8601, kind: kind, model: body["model"], stream: !!body["stream"],
           schema: schema && schema["name"], control: control,
           offered_actions: schema && schema.dig("schema", "properties", "engine_action", "enum"),
           messages: body["messages"], delivered_prompt: body["messages"]&.map { |m| m["content"] }&.join("\n----\n"))

  sleep Float(control["delay"]) if control["delay"]

  if control["unavailable"]
    write_json(socket, { error: { message: "the fake provider is deliberately unavailable" } }.to_json,
               status: "503 Service Unavailable")
    return
  end
  if control["unauthorized"]
    write_json(socket, { error: { message: "no auth credentials found" } }.to_json, status: "401 Unauthorized")
    return
  end

  if schema
    content = synth(schema["schema"], control).to_json
    write_json(socket, json_body(content, body["model"]))
  else
    text = control["text"] || NARRATION
    if body["stream"]
      write_stream(socket, text, body["model"])
    else
      write_json(socket, json_body(text, body["model"]))
    end
  end
end

def read_request(socket)
  request_line = socket.gets
  return nil unless request_line

  method, path, = request_line.split(" ")
  headers = {}
  while (line = socket.gets) && line.strip != ""
    key, value = line.split(":", 2)
    headers[key.downcase.strip] = value.to_s.strip
  end
  length = headers["content-length"].to_i
  body = length.positive? ? socket.read(length) : ""
  { method: method, path: path, headers: headers, body: body }
end

require "time"
server = TCPServer.new("127.0.0.1", PORT)
warn "[fake-provider] listening on 127.0.0.1:#{PORT}"
loop do
  client = server.accept
  Thread.new(client) do |socket|
    begin
      request = read_request(socket)
      next unless request

      case [ request[:method], request[:path].split("?").first ]
      in [ "GET", "/health" ] then write_json(socket, { ok: true }.to_json)
      in [ "POST", "/admin/control" ]
        MUTEX.synchronize { STATE[:control] = JSON.parse(request[:body]) }
        write_json(socket, { ok: true, control: STATE[:control] }.to_json)
      in [ "GET", "/admin/calls" ]
        write_json(socket, MUTEX.synchronize { STATE[:calls].to_json })
      in [ "POST", "/admin/reset" ]
        MUTEX.synchronize { STATE[:calls] = [] }
        write_json(socket, { ok: true }.to_json)
      in [ "POST", "/chat/completions" ] then handle_completion(socket, request)
      else
        write_json(socket, { error: { message: "unhandled #{request[:path]}" } }.to_json, status: "404 Not Found")
      end
    rescue StandardError => e
      warn "[fake-provider] #{e.class}: #{e.message}"
      begin
        write_json(socket, { error: { message: e.message } }.to_json, status: "500 Internal Server Error")
      rescue StandardError
        nil
      end
    ensure
      socket.close rescue nil
    end
  end
end
