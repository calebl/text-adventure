# Live validation of 09b8b05 (fix/npc-arrival-turn-integrity-20260908)

Driven in this run against the **real running app**: `PORT=3142 bin/dev` (Puma +
a Solid Queue worker), an isolated development SQLite database, and headless
Chromium typing into the play box at `http://127.0.0.1:3142`. Port 3000 and the
captain's own development database were untouched.

The application source at `09b8b05` is byte-identical to the reviewed source
`83f56d8` (`git diff 83f56d8 HEAD -- ':!.lavish'` is empty); the later commits
add only report and evidence files.

## No paid model calls

The app was pointed at the deterministic local fixture provider archived with
this branch (`.lavish/adversarial-review-2026-09-08/browser-validation/original-browser-evidence.tar.gz`,
`harness/fake_provider.rb`) on `127.0.0.1:18434`, via `RUBYOPT` and
`OPENROUTER_API_KEY=fake-local-key`. Nothing in the worktree was modified.
`live-provider-call-index.txt` is the complete call ledger: all local, all free.
The synthesized prose ("Maren lets the staff rest...", "The description the world
already recorded.") is fixture text, not model quality — it is deliberately
irrelevant to the world's laws, which is what makes the engine notices legible.

Reproduce:

```bash
FAKE_PORT=18434 FAKE_CALL_LOG=$PWD/calls.jsonl ruby harness/fake_provider.rb &
RAILS_ENV=development bin/rails db:prepare db:seed        # isolated storage/ DBs
PORT=3142 TA_DEBUG_VIEW=0 RUBYOPT="-r$PWD/harness/fake_provider_boot.rb" \
  FAKE_PROVIDER_BASE=http://127.0.0.1:18434 OPENROUTER_API_KEY=fake-local-key bin/dev
```

The seeded world "The Salt Assizes" was played. One fixture row was added before
play so an NPC had something to give: a world-layer item
`salt-warden's brass key` in Ammon Brace's hands.

## What the running app did

| Screenshot | Behavior |
| --- | --- |
| `01-live-arrival-salt-assizes.png` | the seeded world entered from the browser, opening arrival and ways out |
| `02-live-crossing-and-npc-actions.png` | play log after the gift, the follow and the first hazardous crossing |
| `03-live-toll-notices-with-hp-cost.png` | engine crossing notices with exact hit-point costs under prose that never mentions injury |
| `04-live-queued-second-line.png` | a submitted line echoed while the turn is still streaming |
| `05-live-overlapping-turns-in-order.png` | two overlapping submissions, both applied, earlier line first |
| `06-live-refused-dialogue-notice.png` | dialogue model refusing every attempt: truthful failure notice, whole log preserved, nothing applied |
| `07-live-renderer-outage-factual-arrival.png` | every model call refused: the crossing still stands, arrival described from the records |

## Other evidence

- `live-persisted-state.txt` — the receipts (`applied` / `rejected`), the item
  that moved into the party's hands, the follower's row travelling with the
  party, every toll with its damage and the hit points after, and one command
  row per request token across 20 submissions.
- `live-npc-action-closed-sets.txt` — the closed action set the app offered on
  each dialogue call. The one answer outside that set (`give:999999`) was
  rejected by the engine and changed nothing.
- `live-arrival-context-delivered.txt` — the arrival prompt the app actually
  sent for the tolled crossing: live cast, wounds, what is lying there, what is
  carried, and the exact crossing outcome.
- `live-provider-call-index.txt` — the call ledger. One `Location__DetailSchema`
  and one `Location__ExitsSchema` for The Vestry Hulk across six entries into it:
  the room was generated once, at the Location boundary.
- `live-turn-log-transcript.txt` — the play log as the page rendered it.
- `full-suite-result.txt` — `bin/rails test` on this source in this run.

Deeper fault-injection paths (interrupted generation resuming from a stored
checkpoint, an overtaken job writing nothing) were driven on the identical
source in the earlier run and are archived in the branch under
`.lavish/adversarial-review-2026-09-08/browser-validation/`.
